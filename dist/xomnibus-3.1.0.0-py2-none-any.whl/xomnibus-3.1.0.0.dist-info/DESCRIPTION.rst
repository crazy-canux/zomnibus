About this project
==================

Add or remove a user from omnibus DB automatic.

How to use
==========

::

    ./omnibus.py --help
    ./omnibus.py create --help
    ./omnibus.py remove --help

Alternative option:

::

    -F force to rewrite the exist file.

    -P your omnibus/db git repo path.

Deploy option:

::

    -b your request branch.

    -c your commit comment.

Action option:

::

    create

    remote

Create option:

::

    -l last name(family name) as the file name.

    -f firstname

    -g group: Helpdesk Administrator Manager

Remove option:

::

    -s string: search the string and remove the user.

--------------

TODO:
=====

1. Documents.



